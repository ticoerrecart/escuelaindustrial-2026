import db from '$lib/db';
import { json } from '@sveltejs/kit';

export async function GET() {
	const res = await db.execute('SELECT * FROM products');
	return json(res.rows);
}

export async function POST({ request }) {
	const body = await request.json();

	const { name, price, stock } = body;

	const res = await db.execute('INSERT INTO products (name, price, stock) VALUES (?, ?, ?)', [
		name,
		price,
		stock
	]);

	return json({
		id: res.lastInsertRowid
	});
}
