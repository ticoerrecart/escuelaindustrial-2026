import { verifyToken } from "$lib/auth";
import { redirect } from "@sveltejs/kit";

const protectedRoutes = ["/dashboard"];

export async function handle({ event, resolve }) {
  const token = event.cookies.get("token");

  if (token) {
    event.locals.user = verifyToken(token);
  }

  // Check if the current route requires authentication
  const isProtectedRoute = protectedRoutes.some((route) =>
    event.url.pathname.startsWith(route),
  );

  if (isProtectedRoute && !event.locals.user) {
    throw redirect(303, "/login");
  }

  return resolve(event);
}
